package it.unifi.ing.gel.swe.elaborato;

public enum Stato {
	
	VISITATO,
	DA_VISITARE;

}