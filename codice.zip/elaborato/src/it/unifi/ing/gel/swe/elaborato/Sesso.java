package it.unifi.ing.gel.swe.elaborato;

public enum Sesso {
	M,
	F,
	Altro;

}